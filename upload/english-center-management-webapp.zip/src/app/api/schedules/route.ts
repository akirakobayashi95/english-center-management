import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { schedules } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const className = searchParams.get('className') || '';
    const month = searchParams.get('month') || '';
    
    let result = await db.select().from(schedules);
    
    if (className) {
      result = result.filter(s => s.className === className);
    }
    if (month) {
      result = result.filter(s => s.date?.startsWith(month));
    }
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { scheduleId, className, date, dayOfWeek, startTime, endTime, room, teacher, status } = body;
    
    const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
    const dow = dayOfWeek || days[new Date(date).getDay()];
    
    if (scheduleId) {
      await db.update(schedules)
        .set({ className, date, dayOfWeek: dow, startTime, endTime, room, teacher, status })
        .where(eq(schedules.scheduleId, scheduleId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allSchedules = await db.select().from(schedules);
    const newId = `SC${String(allSchedules.length + 1).padStart(3, '0')}`;
    
    await db.insert(schedules).values({
      scheduleId: newId,
      className,
      date,
      dayOfWeek: dow,
      startTime: startTime || '18:00',
      endTime: endTime || '19:30',
      room: room || '',
      teacher: teacher || '',
      status: status || 'Đã lên lịch',
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST schedules error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { scheduleId } = await req.json();
    await db.delete(schedules).where(eq(schedules.scheduleId, scheduleId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
