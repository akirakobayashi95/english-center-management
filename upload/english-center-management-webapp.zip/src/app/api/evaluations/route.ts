import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { evaluations } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const className = searchParams.get('className') || '';
    
    let result = await db.select().from(evaluations);
    if (className) result = result.filter(e => e.className === className);
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { evaluationId, studentId, studentName, className, date, attendScore, testScore, examScore, note, grade } = body;
    
    if (evaluationId) {
      await db.update(evaluations)
        .set({ attendScore, testScore, examScore, note, grade })
        .where(eq(evaluations.evaluationId, evaluationId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allEvals = await db.select().from(evaluations);
    const newId = `E${String(allEvals.length + 1).padStart(3, '0')}`;
    
    await db.insert(evaluations).values({
      evaluationId: newId,
      studentId,
      studentName,
      className,
      date: date || new Date().toISOString().split('T')[0],
      attendScore,
      testScore,
      examScore,
      note: note || '',
      grade,
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST evaluations error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { evaluationId } = await req.json();
    await db.delete(evaluations).where(eq(evaluations.evaluationId, evaluationId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
