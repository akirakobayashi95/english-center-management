import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { classes } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET() {
  try {
    const result = await db.select().from(classes);
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { classId, name, level, teacher, maxStudents, feePerSession, note } = body;
    
    if (classId) {
      await db.update(classes)
        .set({ name, level, teacher, maxStudents, feePerSession, note })
        .where(eq(classes.classId, classId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allClasses = await db.select().from(classes);
    const newId = `C${String(allClasses.length + 1).padStart(3, '0')}`;
    
    await db.insert(classes).values({
      classId: newId,
      name,
      level: level || 'Beginner',
      teacher: teacher || '',
      maxStudents: maxStudents || 25,
      feePerSession: feePerSession || 150000,
      note: note || '',
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST classes error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { classId } = await req.json();
    await db.delete(classes).where(eq(classes.classId, classId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
