import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { students } from '@/db/schema';
import { eq, like, and } from 'drizzle-orm';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const className = searchParams.get('className') || '';
    const search = searchParams.get('search') || '';
    
    if (className && search) {
      const result = await db.select().from(students).where(and(
        eq(students.className, className),
        like(students.name, `%${search}%`)
      ));
      return NextResponse.json({ success: true, data: result });
    } else if (className) {
      const result = await db.select().from(students).where(eq(students.className, className));
      return NextResponse.json({ success: true, data: result });
    } else if (search) {
      const result = await db.select().from(students).where(like(students.name, `%${search}%`));
      return NextResponse.json({ success: true, data: result });
    } else {
      const result = await db.select().from(students);
      return NextResponse.json({ success: true, data: result });
    }
  } catch (error) {
    console.error('GET students error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { studentId, name, birthDate, gender, phone, email, address, className, registerDate, note, status } = body;
    
    if (studentId) {
      await db.update(students)
        .set({ name, birthDate, gender, phone, email, address, className, note, status })
        .where(eq(students.studentId, studentId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allStudents = await db.select().from(students);
    const newId = `S${String(allStudents.length + 1).padStart(3, '0')}`;
    
    await db.insert(students).values({
      studentId: newId,
      name,
      birthDate: birthDate || new Date().toISOString().split('T')[0],
      gender: gender || 'Nam',
      phone: phone || '',
      email: email || '',
      address: address || '',
      className: className || '',
      registerDate: registerDate || new Date().toISOString().split('T')[0],
      note: note || '',
      status: status || 'Đang học',
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST students error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { studentId } = await req.json();
    await db.delete(students).where(eq(students.studentId, studentId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    console.error('DELETE students error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
