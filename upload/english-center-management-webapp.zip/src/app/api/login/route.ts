import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json();
    
    const user = await db.select().from(users).where(eq(users.username, username)).limit(1);
    
    if (user.length === 0 || user[0].password !== password) {
      return NextResponse.json({ success: false, message: 'Sai tên đăng nhập hoặc mật khẩu!' }, { status: 401 });
    }
    
    if (user[0].status !== 'Active') {
      return NextResponse.json({ success: false, message: 'Tài khoản đã bị khóa!' }, { status: 403 });
    }
    
    return NextResponse.json({
      success: true,
      user: {
        id: user[0].userId,
        username: user[0].username,
        name: user[0].fullName,
        role: user[0].role,
      }
    });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
