import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET() {
  try {
    const result = await db.select().from(users);
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, username, password, fullName, role, email, phone, status } = body;
    
    if (userId) {
      await db.update(users)
        .set({ username, password, fullName, role, email, phone, status })
        .where(eq(users.userId, userId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allUsers = await db.select().from(users);
    const newId = `U${String(allUsers.length + 1).padStart(3, '0')}`;
    
    await db.insert(users).values({
      userId: newId,
      username,
      password,
      fullName,
      role: role || 'Giáo viên',
      email: email || '',
      phone: phone || '',
      status: status || 'Active',
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST users error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { userId } = await req.json();
    await db.delete(users).where(eq(users.userId, userId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
