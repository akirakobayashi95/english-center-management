import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { bills } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const className = searchParams.get('className') || '';
    
    let result = await db.select().from(bills);
    if (className) result = result.filter(b => b.className === className);
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { billId, studentId, studentName, className, month, sessions, amount, paid, payDate, status } = body;
    
    if (billId) {
      await db.update(bills)
        .set({ sessions, amount, paid, payDate, status })
        .where(eq(bills.billId, billId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const allBills = await db.select().from(bills);
    const newId = `B${String(allBills.length + 1).padStart(3, '0')}`;
    
    await db.insert(bills).values({
      billId: newId,
      studentId,
      studentName,
      className,
      month: month || '',
      sessions: sessions || 0,
      amount: amount || 0,
      paid: paid || 0,
      payDate: payDate || null,
      status: status || 'Chưa thanh toán',
    });
    
    return NextResponse.json({ success: true, message: 'Thêm thành công!' });
  } catch (error) {
    console.error('POST bills error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { billId } = await req.json();
    await db.delete(bills).where(eq(bills.billId, billId));
    return NextResponse.json({ success: true, message: 'Xóa thành công!' });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
