import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { attendance } from '@/db/schema';
import { eq, and } from 'drizzle-orm';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const className = searchParams.get('className') || '';
    const date = searchParams.get('date') || '';
    const studentId = searchParams.get('studentId') || '';
    const month = searchParams.get('month') || '';
    
    let result = await db.select().from(attendance);
    
    if (className) result = result.filter(a => a.className === className);
    if (date) result = result.filter(a => a.date === date);
    if (studentId) result = result.filter(a => a.studentId === studentId);
    if (month) result = result.filter(a => a.date?.startsWith(month));
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    
    if (body.records) {
      // Bulk save from quick attendance
      for (const record of body.records) {
        const { studentId, className, date, status, note } = record;
        const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
        const dayOfWeek = days[new Date(date).getDay()];
        
        const existing = await db.select().from(attendance)
          .where(and(eq(attendance.studentId, studentId), eq(attendance.date, date)));
        
        if (existing.length > 0) {
          await db.update(attendance)
            .set({ status, note: note || '', checkedAt: new Date() })
            .where(and(eq(attendance.studentId, studentId), eq(attendance.date, date)));
        } else {
          const allAtt = await db.select().from(attendance);
          const newId = `A${String(allAtt.length + 1).padStart(4, '0')}`;
          await db.insert(attendance).values({
            attendanceId: newId,
            studentId,
            className,
            date,
            dayOfWeek,
            status,
            note: note || '',
            checkedAt: new Date(),
          });
        }
      }
      return NextResponse.json({ success: true, message: 'Điểm danh thành công!' });
    }
    
    // Single record save
    const { attendanceId, studentId, className, date, status, note } = body;
    const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
    const dayOfWeek = days[new Date(date).getDay()];
    
    if (attendanceId) {
      await db.update(attendance)
        .set({ status, note: note || '', checkedAt: new Date() })
        .where(eq(attendance.attendanceId, attendanceId));
      return NextResponse.json({ success: true, message: 'Cập nhật thành công!' });
    }
    
    const existing = await db.select().from(attendance)
      .where(and(eq(attendance.studentId, studentId), eq(attendance.date, date)));
    
    if (existing.length > 0) {
      await db.update(attendance)
        .set({ status, note: note || '', checkedAt: new Date() })
        .where(and(eq(attendance.studentId, studentId), eq(attendance.date, date)));
    } else {
      const allAtt = await db.select().from(attendance);
      const newId = `A${String(allAtt.length + 1).padStart(4, '0')}`;
      await db.insert(attendance).values({
        attendanceId: newId,
        studentId,
        className,
        date,
        dayOfWeek,
        status,
        note: note || '',
        checkedAt: new Date(),
      });
    }
    
    return NextResponse.json({ success: true, message: 'Lưu thành công!' });
  } catch (error) {
    console.error('POST attendance error:', error);
    return NextResponse.json({ success: false, message: 'Lỗi server!' }, { status: 500 });
  }
}
