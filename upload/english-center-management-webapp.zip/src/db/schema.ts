import { pgTable, serial, varchar, integer, date, text, timestamp } from 'drizzle-orm/pg-core';

export const students = pgTable('students', {
  id: serial('id').primaryKey(),
  studentId: varchar('student_id', { length: 20 }).notNull().unique(),
  name: varchar('name', { length: 100 }).notNull(),
  birthDate: date('birth_date'),
  gender: varchar('gender', { length: 10 }),
  phone: varchar('phone', { length: 20 }),
  email: varchar('email', { length: 100 }),
  address: text('address'),
  className: varchar('class_name', { length: 100 }),
  registerDate: date('register_date'),
  note: text('note'),
  status: varchar('status', { length: 20 }).default('Đang học'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const classes = pgTable('classes', {
  id: serial('id').primaryKey(),
  classId: varchar('class_id', { length: 20 }).notNull().unique(),
  name: varchar('name', { length: 100 }).notNull(),
  level: varchar('level', { length: 30 }),
  teacher: varchar('teacher', { length: 100 }),
  maxStudents: integer('max_students').default(25),
  feePerSession: integer('fee_per_session').default(150000),
  note: text('note'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const schedules = pgTable('schedules', {
  id: serial('id').primaryKey(),
  scheduleId: varchar('schedule_id', { length: 20 }).notNull().unique(),
  className: varchar('class_name', { length: 100 }).notNull(),
  date: date('date').notNull(),
  dayOfWeek: varchar('day_of_week', { length: 10 }),
  startTime: varchar('start_time', { length: 10 }),
  endTime: varchar('end_time', { length: 10 }),
  room: varchar('room', { length: 20 }),
  teacher: varchar('teacher', { length: 100 }),
  status: varchar('status', { length: 20 }).default('Đã lên lịch'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const attendance = pgTable('attendance', {
  id: serial('id').primaryKey(),
  attendanceId: varchar('attendance_id', { length: 20 }).notNull().unique(),
  studentId: varchar('student_id', { length: 20 }).notNull(),
  className: varchar('class_name', { length: 100 }),
  date: date('date').notNull(),
  dayOfWeek: varchar('day_of_week', { length: 10 }),
  status: varchar('status', { length: 20 }),
  note: text('note'),
  checkedAt: timestamp('checked_at'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const evaluations = pgTable('evaluations', {
  id: serial('id').primaryKey(),
  evaluationId: varchar('evaluation_id', { length: 20 }).notNull().unique(),
  studentId: varchar('student_id', { length: 20 }).notNull(),
  studentName: varchar('student_name', { length: 100 }),
  className: varchar('class_name', { length: 100 }),
  date: date('date'),
  attendScore: integer('attend_score'),
  testScore: integer('test_score'),
  examScore: integer('exam_score'),
  note: text('note'),
  grade: varchar('grade', { length: 20 }),
  createdAt: timestamp('created_at').defaultNow(),
});

export const bills = pgTable('bills', {
  id: serial('id').primaryKey(),
  billId: varchar('bill_id', { length: 20 }).notNull().unique(),
  studentId: varchar('student_id', { length: 20 }).notNull(),
  studentName: varchar('student_name', { length: 100 }),
  className: varchar('class_name', { length: 100 }),
  month: varchar('month', { length: 20 }),
  sessions: integer('sessions'),
  amount: integer('amount'),
  paid: integer('paid').default(0),
  payDate: date('pay_date'),
  status: varchar('status', { length: 30 }).default('Chưa thanh toán'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  userId: varchar('user_id', { length: 20 }).notNull().unique(),
  username: varchar('username', { length: 50 }).notNull(),
  password: varchar('password', { length: 100 }).notNull(),
  fullName: varchar('full_name', { length: 100 }),
  role: varchar('role', { length: 20 }),
  email: varchar('email', { length: 100 }),
  phone: varchar('phone', { length: 20 }),
  status: varchar('status', { length: 20 }).default('Active'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const settings = pgTable('settings', {
  id: serial('id').primaryKey(),
  key: varchar('key', { length: 50 }).notNull().unique(),
  value: text('value'),
  createdAt: timestamp('created_at').defaultNow(),
});
